# coding: latin-1
label = "caf�"
def validate(x): pass
def run():
    validate(label)
